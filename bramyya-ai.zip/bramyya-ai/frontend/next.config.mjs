/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone', // small self-contained server for the Docker image
  poweredByHeader: false,
  compress: false, // Caddy handles compression in front of Next.js
  reactStrictMode: true,
};

export default nextConfig;
