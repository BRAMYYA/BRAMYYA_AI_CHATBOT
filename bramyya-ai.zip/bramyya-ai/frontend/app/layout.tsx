import type { Metadata, Viewport } from 'next';
import { Inter, Noto_Sans_Devanagari, Noto_Sans_Telugu } from 'next/font/google';
import { ClerkProvider } from '@clerk/nextjs';
import { dark } from '@clerk/themes';
import './globals.css';

// next/font downloads these at build time and serves them from your own server.
const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });
const telugu = Noto_Sans_Telugu({ subsets: ['telugu'], variable: '--font-telugu', display: 'swap' });
const deva = Noto_Sans_Devanagari({ subsets: ['devanagari'], variable: '--font-deva', display: 'swap' });

export const metadata: Metadata = {
  title: 'Bramyya AI',
  description: 'Fast multilingual AI assistant: English, हिन्दी, తెలుగు, with voice input and spoken answers.',
  icons: { icon: '/icon.svg' },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#070a19',
};

// Sets the saved language theme before first paint so there is no colour flash.
const themeBoot = `try{var l=localStorage.getItem('bramyya.lang');if(l==='en'||l==='hi'||l==='te'){document.documentElement.dataset.lang=l;document.documentElement.lang=l}}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider appearance={{ baseTheme: dark, variables: { colorPrimary: '#6366f1' } }}>
      <html lang="en" data-lang="en" suppressHydrationWarning className={`${inter.variable} ${telugu.variable} ${deva.variable}`}>
        <head>
          <script dangerouslySetInnerHTML={{ __html: themeBoot }} />
        </head>
        <body className="font-sans">{children}</body>
      </html>
    </ClerkProvider>
  );
}
