import { SignIn } from '@clerk/nextjs';
import Background from '@/components/Background';

export default function SignInPage() {
  return (
    <main className="relative grid min-h-dvh place-items-center overflow-hidden p-4">
      <Background />
      <div className="relative z-10">
        <SignIn />
      </div>
    </main>
  );
}
