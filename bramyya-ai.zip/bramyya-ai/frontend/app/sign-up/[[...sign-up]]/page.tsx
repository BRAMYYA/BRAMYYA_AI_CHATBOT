import { SignUp } from '@clerk/nextjs';
import Background from '@/components/Background';

export default function SignUpPage() {
  return (
    <main className="relative grid min-h-dvh place-items-center overflow-hidden p-4">
      <Background />
      <div className="relative z-10">
        <SignUp />
      </div>
    </main>
  );
}
