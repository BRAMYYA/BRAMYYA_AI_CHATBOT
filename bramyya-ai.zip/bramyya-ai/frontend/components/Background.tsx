// Animated gradient background. Colours are CSS variables, so they cross-fade
// whenever <html data-lang> changes (English = indigo/cyan, Hindi = saffron/gold, Telugu = emerald/teal).
export default function Background() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-0 overflow-hidden">
      <div className="bg-blob animate-float1 -left-[10vw] -top-[15vh] h-[55vmax] w-[55vmax]" style={{ backgroundColor: 'var(--blob-1)' }} />
      <div className="bg-blob animate-float2 -right-[12vw] top-[10vh] h-[50vmax] w-[50vmax]" style={{ backgroundColor: 'var(--blob-2)' }} />
      <div className="bg-blob animate-float3 -bottom-[20vh] left-[20vw] h-[45vmax] w-[45vmax]" style={{ backgroundColor: 'var(--blob-3)' }} />
      <div className="bg-grid" />
    </div>
  );
}
