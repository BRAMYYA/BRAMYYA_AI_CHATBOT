'use client';

import { memo, useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Check, Copy } from 'lucide-react';

function CodeBlock({ children, copyLabel, copiedLabel }: { children: React.ReactNode; copyLabel: string; copiedLabel: string }) {
  const ref = useRef<HTMLPreElement>(null);
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(ref.current?.innerText ?? '');
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard blocked: ignore */
    }
  };

  return (
    <div className="group relative my-3 overflow-hidden rounded-xl border border-white/10 bg-black/40">
      <button
        onClick={copy}
        className="absolute right-2 top-2 flex items-center gap-1 rounded-md bg-white/10 px-2 py-1 text-xs text-white/80 opacity-0 transition hover:bg-white/20 focus:opacity-100 group-hover:opacity-100"
      >
        {copied ? <Check size={12} /> : <Copy size={12} />}
        {copied ? copiedLabel : copyLabel}
      </button>
      <pre ref={ref} className="overflow-x-auto p-4 text-[13px] leading-relaxed">
        {children}
      </pre>
    </div>
  );
}

function Markdown({ children, copyLabel, copiedLabel }: { children: string; copyLabel: string; copiedLabel: string }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      components={{
        a: (props) => <a {...props} target="_blank" rel="noreferrer noopener" className="text-accent2 underline underline-offset-2" />,
        pre: ({ children }) => (
          <CodeBlock copyLabel={copyLabel} copiedLabel={copiedLabel}>
            {children}
          </CodeBlock>
        ),
        code: ({ className, children, ...rest }) =>
          className ? (
            <code className={`${className} font-mono`} {...rest}>
              {children}
            </code>
          ) : (
            <code className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[0.9em]" {...rest}>
              {children}
            </code>
          ),
        ul: (props) => <ul className="ml-5 list-disc space-y-1" {...props} />,
        ol: (props) => <ol className="ml-5 list-decimal space-y-1" {...props} />,
        h1: (props) => <h1 className="mb-2 mt-4 text-xl font-semibold" {...props} />,
        h2: (props) => <h2 className="mb-2 mt-4 text-lg font-semibold" {...props} />,
        h3: (props) => <h3 className="mb-1 mt-3 text-base font-semibold" {...props} />,
        blockquote: (props) => <blockquote className="my-2 border-l-2 border-accent/60 pl-3 text-white/80" {...props} />,
        table: (props) => (
          <div className="my-3 overflow-x-auto">
            <table className="w-full border-collapse text-sm" {...props} />
          </div>
        ),
        th: (props) => <th className="border border-white/15 bg-white/5 px-3 py-1.5 text-left" {...props} />,
        td: (props) => <td className="border border-white/10 px-3 py-1.5" {...props} />,
      }}
    >
      {children}
    </ReactMarkdown>
  );
}

export default memo(Markdown);
