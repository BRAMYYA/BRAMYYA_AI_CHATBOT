'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useAuth, UserButton } from '@clerk/nextjs';
import { Menu, MessageSquare, Mic, Plus, Send, Sparkles, Square, Trash2, Volume2, VolumeX, X } from 'lucide-react';

import Background from '@/components/Background';
import Markdown from '@/components/Markdown';
import { useChatStream } from '@/hooks/useChatStream';
import { useSpeaker, useSpeechRecognition } from '@/hooks/useSpeech';
import { api, type ConversationSummary, type StoredMessage } from '@/lib/api';
import { LANGS, STRINGS, speechCode, type Lang } from '@/lib/i18n';

const LS_LANG = 'bramyya.lang';
const LS_VOICE = 'bramyya.voice';

export default function Chat() {
  const { getToken } = useAuth();

  const [lang, setLang] = useState<Lang>('en');
  const [voiceOn, setVoiceOn] = useState(true);
  const [input, setInput] = useState('');
  const [convId, setConvId] = useState<string | null>(null);
  const [conversations, setConversations] = useState<ConversationSummary[]>([]);
  const [sidebar, setSidebar] = useState(false);

  const S = STRINGS[lang];
  const { messages, streaming, firstTokenSeen, send, stop, reset, load } = useChatStream();
  const speaker = useSpeaker(speechCode(lang));

  const voiceRef = useRef(voiceOn);
  voiceRef.current = voiceOn;
  const convRef = useRef(convId);
  convRef.current = convId;
  const scrollRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  /* ---------- load saved preferences ---------- */
  useEffect(() => {
    try {
      const l = localStorage.getItem(LS_LANG) as Lang | null;
      if (l && ['en', 'hi', 'te'].includes(l)) setLang(l);
      const v = localStorage.getItem(LS_VOICE);
      if (v !== null) setVoiceOn(v === '1');
    } catch {
      /* storage unavailable */
    }
    (async () => {
      try {
        const token = await getToken();
        if (!token) return;
        const s = await api<{ language?: Lang; voice_enabled?: boolean }>('/api/me/settings', token);
        if (s.language && ['en', 'hi', 'te'].includes(s.language)) setLang(s.language);
        if (typeof s.voice_enabled === 'boolean') setVoiceOn(s.voice_enabled);
      } catch {
        /* settings are optional */
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- the language drives the whole colour theme ---------- */
  useEffect(() => {
    document.documentElement.dataset.lang = lang;
    document.documentElement.lang = lang;
  }, [lang]);

  const saveSettings = useCallback(
    async (patch: { language?: Lang; voice_enabled?: boolean }) => {
      try {
        const token = await getToken();
        if (token) await api('/api/me/settings', token, { method: 'PUT', body: JSON.stringify(patch) });
      } catch {
        /* best effort */
      }
    },
    [getToken],
  );

  const changeLang = (l: Lang) => {
    if (l === lang) return;
    speaker.cancel();
    setLang(l);
    try {
      localStorage.setItem(LS_LANG, l);
    } catch {}
    void saveSettings({ language: l });
  };

  const toggleVoice = () => {
    const next = !voiceOn;
    setVoiceOn(next);
    if (!next) speaker.cancel();
    try {
      localStorage.setItem(LS_VOICE, next ? '1' : '0');
    } catch {}
    void saveSettings({ voice_enabled: next });
  };

  /* ---------- history ---------- */
  const refreshHistory = useCallback(async () => {
    try {
      const token = await getToken();
      if (!token) return;
      setConversations(await api<ConversationSummary[]>('/api/conversations', token));
    } catch {
      /* ignore */
    }
  }, [getToken]);

  useEffect(() => {
    void refreshHistory();
  }, [refreshHistory]);

  const openConversation = async (id: string) => {
    speaker.cancel();
    stop();
    setSidebar(false);
    try {
      const token = await getToken();
      if (!token) return;
      const rows = await api<StoredMessage[]>(`/api/conversations/${id}/messages`, token);
      load(rows.map((r) => ({ id: r.id, role: r.role, content: r.content })));
      setConvId(id);
    } catch {
      /* ignore */
    }
  };

  const newChat = () => {
    speaker.cancel();
    reset();
    setConvId(null);
    setSidebar(false);
    textareaRef.current?.focus();
  };

  const removeConversation = async (id: string) => {
    try {
      const token = await getToken();
      if (!token) return;
      await api(`/api/conversations/${id}`, token, { method: 'DELETE' });
      if (convRef.current === id) newChat();
      void refreshHistory();
    } catch {
      /* ignore */
    }
  };

  /* ---------- sending ---------- */
  const submit = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || streaming) return;
      speaker.cancel();
      speaker.prime();
      setInput('');
      const token = await getToken();
      if (!token) return;
      stickRef.current = true;
      await send({
        text,
        language: lang,
        token,
        conversationId: convRef.current,
        errorText: S.error,
        onMeta: (id) => {
          if (!convRef.current) setConvId(id);
        },
        onToken: (t) => {
          if (voiceRef.current) speaker.feed(t); // speak while the answer is still being generated
        },
        onDone: () => {
          if (voiceRef.current) speaker.flush();
          void refreshHistory();
        },
      });
    },
    [streaming, speaker, getToken, send, lang, S.error, refreshHistory],
  );

  /* ---------- microphone ---------- */
  const mic = useSpeechRecognition(speechCode(lang), (text) => void submit(text));
  const toggleMic = () => {
    if (mic.listening) {
      mic.stop();
    } else {
      speaker.cancel(); // never listen to our own voice
      mic.start();
    }
  };

  /* ---------- auto-scroll (only while the user is near the bottom) ---------- */
  useEffect(() => {
    const el = scrollRef.current;
    if (el && stickRef.current) el.scrollTo({ top: el.scrollHeight });
  }, [messages]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (el) stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
  };

  /* ---------- textarea auto-grow (fallback for browsers without field-sizing) ---------- */
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = `${Math.min(ta.scrollHeight, 180)}px`;
  }, [input, mic.interim]);

  const shownInput = mic.listening && mic.interim ? mic.interim : input;
  const lastIsEmptyAssistant = streaming && !firstTokenSeen;
  const micMessage =
    mic.error === 'denied' ? S.micDenied : mic.error === 'unsupported' || !mic.supported ? S.micUnsupported : null;
  const status = mic.listening ? S.listening : speaker.speaking ? S.speaking : lastIsEmptyAssistant ? S.thinking : null;

  return (
    <div className="relative flex h-dvh overflow-hidden">
      <Background />

      {/* ---------------- sidebar ---------------- */}
      {sidebar && <div className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={() => setSidebar(false)} />}
      <aside
        className={`glass fixed inset-y-0 left-0 z-40 flex w-72 flex-col transition-transform duration-300 md:static md:translate-x-0 ${
          sidebar ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-2 font-semibold">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-accent to-accent2">
              <Sparkles size={16} className="text-white" />
            </span>
            Bramyya AI
          </div>
          <button className="rounded-lg p-1.5 hover:bg-white/10 md:hidden" onClick={() => setSidebar(false)} aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="px-4 pb-3">
          <button
            onClick={newChat}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-accent to-accent2 px-4 py-2.5 text-sm font-medium text-black/80 shadow-lg shadow-accent/20 transition hover:brightness-110"
          >
            <Plus size={16} /> {S.newChat}
          </button>
        </div>

        <div className="px-4 pb-2 text-xs font-medium uppercase tracking-wider text-white/40">{S.history}</div>
        <nav className="flex-1 space-y-1 overflow-y-auto px-2 pb-4">
          {conversations.length === 0 && <p className="px-3 py-2 text-sm text-white/40">{S.noHistory}</p>}
          {conversations.map((c) => (
            <div
              key={c.id}
              className={`group flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition ${
                c.id === convId ? 'bg-accent/20 text-white' : 'text-white/70 hover:bg-white/5'
              }`}
            >
              <button className="flex min-w-0 flex-1 items-center gap-2 text-left" onClick={() => void openConversation(c.id)}>
                <MessageSquare size={14} className="shrink-0 opacity-60" />
                <span className="truncate">{c.title}</span>
              </button>
              <button
                title={S.delete}
                aria-label={S.delete}
                onClick={() => void removeConversation(c.id)}
                className="rounded p-1 text-white/40 opacity-0 transition hover:bg-white/10 hover:text-white group-hover:opacity-100 focus:opacity-100"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </nav>
      </aside>

      {/* ---------------- main column ---------------- */}
      <main className="relative z-10 flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-3 px-3 py-3 sm:px-6">
          <button className="rounded-lg p-2 hover:bg-white/10 md:hidden" onClick={() => setSidebar(true)} aria-label="Menu">
            <Menu size={20} />
          </button>

          {/* language switcher: changes the colour theme */}
          <div className="glass mx-auto flex items-center gap-1 rounded-full p-1">
            {LANGS.map((l) => (
              <button
                key={l.code}
                onClick={() => changeLang(l.code)}
                aria-pressed={lang === l.code}
                className={`rounded-full px-3.5 py-1.5 text-sm font-medium transition-all duration-300 sm:px-5 ${
                  lang === l.code
                    ? 'bg-gradient-to-r from-accent to-accent2 text-black/85 shadow-md shadow-accent/30'
                    : 'text-white/70 hover:bg-white/10'
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={toggleVoice}
              title={voiceOn ? S.speakerOn : S.speakerOff}
              aria-label={voiceOn ? S.speakerOn : S.speakerOff}
              className={`relative rounded-full p-2.5 transition ${voiceOn ? 'bg-accent/25 text-accent2' : 'text-white/50 hover:bg-white/10'}`}
            >
              {voiceOn ? <Volume2 size={19} /> : <VolumeX size={19} />}
              {speaker.speaking && <span className="absolute right-1 top-1 h-2 w-2 animate-ping rounded-full bg-accent2" />}
            </button>
            <UserButton />
          </div>
        </header>

        {/* messages */}
        <div ref={scrollRef} onScroll={onScroll} className="flex-1 overflow-y-auto px-3 sm:px-6">
          <div className="mx-auto flex max-w-3xl flex-col gap-5 pb-6 pt-2">
            {messages.length === 0 && (
              <div className="animate-rise flex flex-col items-center pt-[10vh] text-center">
                <div className="mb-6 grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-accent to-accent2 shadow-2xl shadow-accent/30">
                  <Sparkles size={36} className="text-white" />
                </div>
                <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">{S.greeting}</h1>
                <p className="mt-3 max-w-md text-white/60">{S.hint}</p>
                <div className="mt-8 grid w-full max-w-xl grid-cols-1 gap-3 sm:grid-cols-2">
                  {S.suggestions.map((s) => (
                    <button
                      key={s}
                      onClick={() => void submit(s)}
                      className="glass rounded-2xl px-4 py-3 text-left text-sm text-white/80 transition hover:border-accent/50 hover:bg-white/10"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m, i) => {
              const isLast = i === messages.length - 1;
              const showCaret = isLast && streaming && m.role === 'assistant';
              return m.role === 'user' ? (
                <div key={m.id} className="animate-rise flex justify-end">
                  <div className="chat-text max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-gradient-to-br from-accent to-accent2 px-4 py-2.5 text-black/85 shadow-lg shadow-accent/20">
                    {m.content}
                  </div>
                </div>
              ) : (
                <div key={m.id} className="animate-rise flex gap-3">
                  <span className="mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-accent to-accent2">
                    <Sparkles size={15} className="text-white" />
                  </span>
                  <div
                    className={`glass chat-text min-w-0 max-w-[88%] rounded-2xl rounded-tl-md px-4 py-3 ${
                      m.error ? 'border-red-400/40 text-red-200' : ''
                    }`}
                  >
                    {m.content ? (
                      <Markdown copyLabel={S.copy} copiedLabel={S.copied}>
                        {m.content}
                      </Markdown>
                    ) : (
                      <span className="flex h-6 items-end gap-1" aria-label={S.thinking}>
                        {[0, 1, 2, 3].map((n) => (
                          <i key={n} className="h-4 w-1 origin-bottom animate-bars rounded-full bg-accent2" style={{ animationDelay: `${n * 0.12}s` }} />
                        ))}
                      </span>
                    )}
                    {showCaret && m.content && <span className="ml-0.5 inline-block h-4 w-[2px] translate-y-0.5 animate-caret bg-accent2" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* composer */}
        <div className="px-3 pb-4 sm:px-6">
          <div className="mx-auto max-w-3xl">
            <div className="mb-2 flex h-5 items-center justify-center gap-2 text-xs text-white/60">
              {status && (
                <>
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent2" />
                  {status}
                </>
              )}
              {!status && micMessage && <span className="text-amber-300/90">{micMessage}</span>}
              {!status && !micMessage && voiceOn && !speaker.hasVoice && <span className="text-amber-300/90">{S.noVoice}</span>}
            </div>

            <div className="glass flex items-end gap-2 rounded-3xl p-2 shadow-2xl shadow-black/30 transition focus-within:border-accent/60">
              <button
                onClick={toggleMic}
                title={mic.listening ? S.micOff : S.micOn}
                aria-label={mic.listening ? S.micOff : S.micOn}
                className={`grid h-11 w-11 shrink-0 place-items-center rounded-full transition ${
                  mic.listening ? 'animate-pulseRing bg-accent text-white' : 'bg-white/10 text-white/80 hover:bg-white/20'
                }`}
              >
                <Mic size={20} />
              </button>

              <textarea
                ref={textareaRef}
                rows={1}
                value={shownInput}
                readOnly={mic.listening}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                    e.preventDefault();
                    void submit(input);
                  }
                }}
                placeholder={mic.listening ? S.listening : S.placeholder}
                className="max-h-44 min-h-[44px] flex-1 resize-none bg-transparent px-2 py-2.5 text-[15px] leading-6 outline-none placeholder:text-white/35"
              />

              {streaming ? (
                <button
                  onClick={() => {
                    stop();
                    speaker.cancel();
                  }}
                  title={S.stop}
                  aria-label={S.stop}
                  className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white/15 text-white transition hover:bg-white/25"
                >
                  <Square size={16} fill="currentColor" />
                </button>
              ) : (
                <button
                  onClick={() => void submit(input)}
                  disabled={!input.trim()}
                  title={S.send}
                  aria-label={S.send}
                  className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-gradient-to-br from-accent to-accent2 text-black/80 shadow-lg shadow-accent/30 transition enabled:hover:brightness-110 disabled:opacity-30"
                >
                  <Send size={18} />
                </button>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
