'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

/* ============================================================================
 * Microphone: Web Speech API recognition (Chrome, Edge, Android Chrome, Safari 14.1+)
 * Needs HTTPS (or localhost), which Caddy provides for bramyya.duckdns.org.
 * ========================================================================== */
export type MicError = 'denied' | 'unsupported' | 'other' | null;

export function useSpeechRecognition(langCode: string, onFinal: (text: string) => void) {
  const [supported, setSupported] = useState(true);
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState('');
  const [error, setError] = useState<MicError>(null);

  const recRef = useRef<any>(null);
  const onFinalRef = useRef(onFinal);
  onFinalRef.current = onFinal;

  useEffect(() => {
    const w = window as any;
    setSupported(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition));
    return () => recRef.current?.abort?.();
  }, []);

  const start = useCallback(() => {
    const w = window as any;
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) {
      setError('unsupported');
      return;
    }
    recRef.current?.abort?.();
    const rec = new SR();
    rec.lang = langCode;
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;

    let finalText = '';
    setError(null);
    setInterim('');

    rec.onstart = () => setListening(true);
    rec.onresult = (e: any) => {
      let interimText = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) finalText += r[0].transcript;
        else interimText += r[0].transcript;
      }
      setInterim((finalText + interimText).trim());
    };
    rec.onerror = (e: any) => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') setError('denied');
      else if (e.error !== 'no-speech' && e.error !== 'aborted') setError('other');
    };
    rec.onend = () => {
      setListening(false);
      setInterim('');
      const text = finalText.trim();
      if (text) onFinalRef.current(text);
    };

    recRef.current = rec;
    try {
      rec.start();
    } catch {
      setError('other');
    }
  }, [langCode]);

  const stop = useCallback(() => recRef.current?.stop?.(), []);

  return { supported, listening, interim, error, start, stop };
}

/* ============================================================================
 * Speaker: speechSynthesis that talks WHILE the answer is still being generated.
 * Tokens are fed in as they arrive; every completed sentence is queued immediately.
 * ========================================================================== */
const SENTENCE_END = /([.!?।॥]+["')\]]*)(\s+)|(\n+)/;

function cleanForSpeech(text: string): string {
  return text
    .replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1') // markdown links -> link text
    .replace(/https?:\/\/\S+/g, '')
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/^\s*\d+[.)]\s+/gm, '')
    .replace(/[*_#>`~|]/g, '')
    .replace(/\p{Extended_Pictographic}/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export function useSpeaker(langCode: string) {
  const [speaking, setSpeaking] = useState(false);
  const [hasVoice, setHasVoice] = useState(true);

  const bufRef = useRef(''); // text not yet spoken
  const carryRef = useRef(''); // short sentences held back so speech is not choppy
  const inCodeRef = useRef(false);
  const pendingRef = useRef(0);
  const genRef = useRef(0); // bumped on cancel so stale callbacks are ignored
  const voiceRef = useRef<SpeechSynthesisVoice | null>(null);
  const langRef = useRef(langCode);
  langRef.current = langCode;

  const pickVoice = useCallback(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    const voices = window.speechSynthesis.getVoices();
    if (!voices.length) return; // not loaded yet; voiceschanged will call us again
    const code = langRef.current.toLowerCase();
    const base = code.split('-')[0];
    const match =
      voices.find((v) => v.lang.toLowerCase() === code) ||
      voices.find((v) => v.lang.toLowerCase().replace('_', '-') === code) ||
      voices.find((v) => v.lang.toLowerCase().startsWith(base)) ||
      null;
    voiceRef.current = match;
    setHasVoice(Boolean(match));
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setHasVoice(false);
      return;
    }
    pickVoice();
    window.speechSynthesis.addEventListener('voiceschanged', pickVoice);
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', pickVoice);
      window.speechSynthesis.cancel();
    };
  }, [pickVoice]);

  useEffect(() => {
    pickVoice();
  }, [langCode, pickVoice]);

  const speakNow = useCallback((raw: string) => {
    const text = cleanForSpeech(raw);
    if (!text || !('speechSynthesis' in window)) return;
    const gen = genRef.current;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = langRef.current;
    if (voiceRef.current) u.voice = voiceRef.current;
    u.rate = 1;
    u.onstart = () => {
      if (gen === genRef.current) setSpeaking(true);
    };
    const finished = () => {
      if (gen !== genRef.current) return;
      pendingRef.current = Math.max(0, pendingRef.current - 1);
      if (pendingRef.current === 0) setSpeaking(false);
    };
    u.onend = finished;
    u.onerror = finished;
    pendingRef.current += 1;
    window.speechSynthesis.speak(u);
  }, []);

  const emit = useCallback(
    (sentence: string, force = false) => {
      carryRef.current += sentence;
      if (force || carryRef.current.length >= 25) {
        speakNow(carryRef.current);
        carryRef.current = '';
      }
    },
    [speakNow],
  );

  /** Call with every token as it arrives from the stream. */
  const feed = useCallback(
    (chunk: string) => {
      // Skip fenced code blocks: reading code aloud is useless.
      chunk.split('```').forEach((seg, i) => {
        if (i > 0) inCodeRef.current = !inCodeRef.current;
        if (!inCodeRef.current) bufRef.current += seg;
      });

      for (;;) {
        const m = SENTENCE_END.exec(bufRef.current);
        if (!m) break;
        const end = m.index + m[0].length;
        const sentence = bufRef.current.slice(0, end);
        bufRef.current = bufRef.current.slice(end);
        emit(sentence);
      }
      // Very long run without punctuation: cut at the last space so speech still starts promptly.
      if (bufRef.current.length > 240) {
        const cut = bufRef.current.lastIndexOf(' ', 200);
        if (cut > 40) {
          emit(bufRef.current.slice(0, cut + 1));
          bufRef.current = bufRef.current.slice(cut + 1);
        }
      }
    },
    [emit],
  );

  /** Call when the stream finishes: speak whatever is left. */
  const flush = useCallback(() => {
    const rest = carryRef.current + bufRef.current;
    carryRef.current = '';
    bufRef.current = '';
    inCodeRef.current = false;
    speakNow(rest);
  }, [speakNow]);

  const cancel = useCallback(() => {
    genRef.current += 1;
    pendingRef.current = 0;
    bufRef.current = '';
    carryRef.current = '';
    inCodeRef.current = false;
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    setSpeaking(false);
  }, []);

  /** Call inside a click/tap handler: iOS Safari only allows speech that starts from a user gesture. */
  const prime = useCallback(() => {
    if (!('speechSynthesis' in window)) return;
    const u = new SpeechSynthesisUtterance('');
    u.volume = 0;
    window.speechSynthesis.speak(u);
  }, []);

  return { speaking, hasVoice, feed, flush, cancel, prime };
}
