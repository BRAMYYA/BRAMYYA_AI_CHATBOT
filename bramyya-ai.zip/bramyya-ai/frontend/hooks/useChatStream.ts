'use client';

import { useCallback, useRef, useState } from 'react';
import { API_BASE } from '@/lib/api';
import type { Lang } from '@/lib/i18n';

export interface ChatMsg {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  error?: boolean;
}

interface SendOptions {
  text: string;
  language: Lang;
  token: string;
  conversationId: string | null;
  errorText: string;
  onMeta?: (conversationId: string) => void;
  onToken?: (token: string) => void; // raw token, delivered immediately (used by the speaker)
  onDone?: () => void;
}

/**
 * Reads the Server-Sent Events stream from POST /api/chat/stream.
 * EventSource only supports GET, so we use fetch() + ReadableStream and parse the SSE frames ourselves.
 * Tokens are batched per animation frame, so the UI re-renders at most ~60x/second however fast Groq streams.
 */
export function useChatStream() {
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [streaming, setStreaming] = useState(false);
  const [firstTokenSeen, setFirstTokenSeen] = useState(false);

  const abortRef = useRef<AbortController | null>(null);
  const bufferRef = useRef('');
  const rafRef = useRef<number | null>(null);
  const assistantIdRef = useRef('');

  const flush = useCallback(() => {
    rafRef.current = null;
    const chunk = bufferRef.current;
    if (!chunk) return;
    bufferRef.current = '';
    const id = assistantIdRef.current;
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, content: m.content + chunk } : m)));
  }, []);

  const queueToken = useCallback(
    (t: string) => {
      bufferRef.current += t;
      if (rafRef.current === null) rafRef.current = requestAnimationFrame(flush);
    },
    [flush],
  );

  const send = useCallback(
    async (o: SendOptions) => {
      const userId = crypto.randomUUID();
      const assistantId = crypto.randomUUID();
      assistantIdRef.current = assistantId;
      bufferRef.current = '';
      setFirstTokenSeen(false);
      setMessages((p) => [
        ...p,
        { id: userId, role: 'user', content: o.text },
        { id: assistantId, role: 'assistant', content: '' },
      ]);
      setStreaming(true);

      const ctrl = new AbortController();
      abortRef.current = ctrl;
      let failed = false;

      const handleFrame = (raw: string) => {
        let event = 'message';
        const dataLines: string[] = [];
        for (const line of raw.split('\n')) {
          if (line.startsWith('event:')) event = line.slice(6).trim();
          else if (line.startsWith('data:')) dataLines.push(line.slice(5).trimStart());
        }
        if (!dataLines.length) return;
        const data = JSON.parse(dataLines.join('\n'));
        if (event === 'meta') o.onMeta?.(data.conversation_id);
        else if (event === 'token') {
          setFirstTokenSeen(true);
          queueToken(data.t);
          o.onToken?.(data.t);
        } else if (event === 'error') {
          failed = true;
          setMessages((p) =>
            p.map((m) => (m.id === assistantId ? { ...m, content: m.content || data.message || o.errorText, error: true } : m)),
          );
        }
      };

      try {
        const res = await fetch(`${API_BASE}/api/chat/stream`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'text/event-stream',
            Authorization: `Bearer ${o.token}`,
          },
          body: JSON.stringify({ message: o.text, conversation_id: o.conversationId, language: o.language }),
          signal: ctrl.signal,
        });
        if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buf = '';
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          let idx: number;
          while ((idx = buf.indexOf('\n\n')) !== -1) {
            const frame = buf.slice(0, idx);
            buf = buf.slice(idx + 2);
            handleFrame(frame);
          }
        }
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          failed = true;
          setMessages((p) =>
            p.map((m) => (m.id === assistantId ? { ...m, content: m.content || o.errorText, error: true } : m)),
          );
        }
      } finally {
        if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
        flush();
        setStreaming(false);
        abortRef.current = null;
        if (!failed) o.onDone?.();
      }
    },
    [flush, queueToken],
  );

  const stop = useCallback(() => abortRef.current?.abort(), []);
  const reset = useCallback(() => {
    abortRef.current?.abort();
    setMessages([]);
  }, []);
  const load = useCallback((msgs: ChatMsg[]) => setMessages(msgs), []);

  return { messages, streaming, firstTokenSeen, send, stop, reset, load };
}
