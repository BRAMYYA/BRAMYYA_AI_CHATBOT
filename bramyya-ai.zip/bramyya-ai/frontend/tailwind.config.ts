import type { Config } from 'tailwindcss';

// Colours come from CSS variables in globals.css, which change with <html data-lang="...">.
// That is how the whole UI re-colours when the language is switched.
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}', './hooks/**/*.{ts,tsx}', './lib/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        accent: 'rgb(var(--accent) / <alpha-value>)',
        accent2: 'rgb(var(--accent-2) / <alpha-value>)',
        base: 'rgb(var(--bg) / <alpha-value>)',
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'var(--font-telugu)', 'var(--font-deva)', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        float1: { '0%,100%': { transform: 'translate(0,0) scale(1)' }, '50%': { transform: 'translate(8vw,6vh) scale(1.15)' } },
        float2: { '0%,100%': { transform: 'translate(0,0) scale(1)' }, '50%': { transform: 'translate(-7vw,-8vh) scale(1.2)' } },
        float3: { '0%,100%': { transform: 'translate(0,0) scale(1)' }, '50%': { transform: 'translate(5vw,-6vh) scale(0.9)' } },
        pulseRing: { '0%': { boxShadow: '0 0 0 0 rgb(var(--accent) / 0.55)' }, '100%': { boxShadow: '0 0 0 18px rgb(var(--accent) / 0)' } },
        rise: { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        caret: { '0%,100%': { opacity: '1' }, '50%': { opacity: '0' } },
        bars: { '0%,100%': { transform: 'scaleY(0.3)' }, '50%': { transform: 'scaleY(1)' } },
      },
      animation: {
        float1: 'float1 18s ease-in-out infinite',
        float2: 'float2 22s ease-in-out infinite',
        float3: 'float3 26s ease-in-out infinite',
        pulseRing: 'pulseRing 1.3s ease-out infinite',
        rise: 'rise .35s ease-out both',
        caret: 'caret 1s steps(1) infinite',
        bars: 'bars 0.9s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;
