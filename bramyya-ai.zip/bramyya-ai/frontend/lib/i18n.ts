export type Lang = 'en' | 'hi' | 'te';

export const LANGS: { code: Lang; label: string; speech: string }[] = [
  { code: 'en', label: 'English', speech: 'en-IN' },
  { code: 'hi', label: 'हिन्दी', speech: 'hi-IN' },
  { code: 'te', label: 'తెలుగు', speech: 'te-IN' },
];

export const speechCode = (lang: Lang) => LANGS.find((l) => l.code === lang)!.speech;

export interface Strings {
  greeting: string;
  hint: string;
  placeholder: string;
  newChat: string;
  history: string;
  noHistory: string;
  send: string;
  stop: string;
  listening: string;
  speaking: string;
  thinking: string;
  micOn: string;
  micOff: string;
  speakerOn: string;
  speakerOff: string;
  micDenied: string;
  micUnsupported: string;
  noVoice: string;
  error: string;
  copy: string;
  copied: string;
  delete: string;
  suggestions: string[];
}

export const STRINGS: Record<Lang, Strings> = {
  en: {
    greeting: 'Hello! I am your AI assistant',
    hint: 'Ask me anything. Type, or tap the mic and speak.',
    placeholder: 'Type your message…',
    newChat: 'New chat',
    history: 'History',
    noHistory: 'No chats yet',
    send: 'Send',
    stop: 'Stop',
    listening: 'Listening…',
    speaking: 'Speaking…',
    thinking: 'Thinking…',
    micOn: 'Start voice input',
    micOff: 'Stop listening',
    speakerOn: 'Read answers aloud: on',
    speakerOff: 'Read answers aloud: off',
    micDenied: 'Microphone permission was blocked. Allow it in your browser settings.',
    micUnsupported: 'Voice input is not supported in this browser. Please use Chrome or Edge.',
    noVoice: 'No English voice is installed on this device, so spoken answers may not work.',
    error: 'Something went wrong. Please try again.',
    copy: 'Copy',
    copied: 'Copied',
    delete: 'Delete',
    suggestions: [
      'Tell me about yourself',
      'Tell me a short story',
      'What is cloud computing?',
      'What should I learn today?',
    ],
  },
  hi: {
    greeting: 'नमस्ते! मैं आपका AI सहायक हूँ',
    hint: 'कुछ भी पूछें। टाइप करें, या माइक दबाकर बोलें।',
    placeholder: 'अपना संदेश लिखें…',
    newChat: 'नई चैट',
    history: 'इतिहास',
    noHistory: 'अभी कोई चैट नहीं',
    send: 'भेजें',
    stop: 'रोकें',
    listening: 'सुन रहा हूँ…',
    speaking: 'बोल रहा हूँ…',
    thinking: 'सोच रहा हूँ…',
    micOn: 'बोलकर लिखना शुरू करें',
    micOff: 'सुनना बंद करें',
    speakerOn: 'उत्तर बोलकर सुनाएँ: चालू',
    speakerOff: 'उत्तर बोलकर सुनाएँ: बंद',
    micDenied: 'माइक्रोफ़ोन की अनुमति रोकी गई है। कृपया ब्राउज़र सेटिंग में अनुमति दें।',
    micUnsupported: 'इस ब्राउज़र में वॉइस इनपुट उपलब्ध नहीं है। कृपया Chrome या Edge का उपयोग करें।',
    noVoice: 'इस डिवाइस पर हिंदी आवाज़ इंस्टॉल नहीं है, इसलिए उत्तर बोलकर नहीं सुनाए जा सकते।',
    error: 'कुछ गड़बड़ हो गई। कृपया फिर से कोशिश करें।',
    copy: 'कॉपी',
    copied: 'कॉपी हो गया',
    delete: 'हटाएँ',
    suggestions: [
      'अपने बारे में बताइए',
      'एक छोटी कहानी सुनाइए',
      'क्लाउड कंप्यूटिंग क्या है?',
      'आज मुझे क्या सीखना चाहिए?',
    ],
  },
  te: {
    greeting: 'నమస్కారం! నేను మీ AI సహాయకుడిని',
    hint: 'ఏదైనా అడగండి. టైప్ చేయండి, లేదా మైక్ నొక్కి మాట్లాడండి.',
    placeholder: 'మీ సందేశాన్ని టైప్ చేయండి…',
    newChat: 'కొత్త చాట్',
    history: 'చరిత్ర',
    noHistory: 'ఇంకా చాట్‌లు లేవు',
    send: 'పంపండి',
    stop: 'ఆపండి',
    listening: 'వింటున్నాను…',
    speaking: 'చెబుతున్నాను…',
    thinking: 'ఆలోచిస్తున్నాను…',
    micOn: 'మాట్లాడి టైప్ చేయడం ప్రారంభించండి',
    micOff: 'వినడం ఆపండి',
    speakerOn: 'సమాధానాలు చదివి వినిపించు: ఆన్',
    speakerOff: 'సమాధానాలు చదివి వినిపించు: ఆఫ్',
    micDenied: 'మైక్రోఫోన్ అనుమతి నిరోధించబడింది. దయచేసి బ్రౌజర్ సెట్టింగ్‌లలో అనుమతించండి.',
    micUnsupported: 'ఈ బ్రౌజర్‌లో వాయిస్ ఇన్‌పుట్ లేదు. దయచేసి Chrome లేదా Edge ఉపయోగించండి.',
    noVoice: 'ఈ పరికరంలో తెలుగు వాయిస్ ఇన్‌స్టాల్ చేయలేదు, కాబట్టి సమాధానాలు వినిపించకపోవచ్చు.',
    error: 'ఏదో తప్పు జరిగింది. దయచేసి మళ్లీ ప్రయత్నించండి.',
    copy: 'కాపీ',
    copied: 'కాపీ అయింది',
    delete: 'తొలగించు',
    suggestions: [
      'మీ గురించి చెప్పండి',
      'ఒక చిన్న కథ చెప్పండి',
      'క్లౌడ్ కంప్యూటింగ్ అంటే ఏమిటి?',
      'ఈరోజు నేను ఏం నేర్చుకోవాలి?',
    ],
  },
};
