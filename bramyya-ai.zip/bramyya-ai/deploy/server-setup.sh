#!/usr/bin/env bash
# One-time preparation of a fresh Ubuntu/Debian server: installs Docker and opens the web ports.
# Usage:  bash deploy/server-setup.sh
set -euo pipefail

echo ">> Installing Docker (includes the 'docker compose' plugin)"
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"

echo ">> Opening firewall ports (SSH, HTTP, HTTPS)"
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 443/udp
sudo ufw --force enable

echo
echo "Done. Log out and log back in once so the docker group takes effect, then continue with README step 6."
echo "Also remember: your cloud provider's own firewall / security group must allow ports 80 and 443."
