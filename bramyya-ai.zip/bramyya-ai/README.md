# Bramyya AI — personal multilingual voice chatbot

Live at **https://bramyya.duckdns.org** · English / हिन्दी / తెలుగు · mic input · spoken answers · $0/month

```
Browser ──HTTPS──> Caddy (auto TLS, bramyya.duckdns.org)
                     ├── /api/*  ──> FastAPI (Clerk token check) ──> Supabase Postgres (history)
                     │                         └──────────────────> Groq (stream=True) ──SSE──> browser
                     └── /*      ──> Next.js (UI)
Clerk (hosted, free) handles sign-in; DuckDNS container keeps the domain pointed at your server.
```

## Project layout

```
bramyya-ai/
├── docker-compose.yml        # caddy + frontend + backend + duckdns
├── Caddyfile                 # HTTPS + routing + SSE-safe proxying
├── .env.example              # every secret you must fill in (copy to .env)
├── deploy/server-setup.sh    # installs Docker, opens ports (run once on the server)
├── backend/
│   ├── main.py               # FastAPI: Clerk middleware, Supabase interface, /api/chat/stream, Mangum handler
│   ├── requirements.txt
│   ├── supabase_schema.sql   # run once in Supabase SQL editor
│   └── Dockerfile
└── frontend/
    ├── package.json, tsconfig.json, next.config.mjs, tailwind.config.ts, postcss.config.js
    ├── middleware.ts         # Clerk route protection
    ├── Dockerfile
    ├── app/                  # layout.tsx, page.tsx, globals.css (language colour themes), sign-in/, sign-up/
    ├── components/           # Chat.tsx (main UI), Markdown.tsx, Background.tsx
    ├── hooks/                # useChatStream.ts (SSE), useSpeech.ts (mic + speaker)
    ├── lib/                  # i18n.ts (3 languages), api.ts
    └── public/icon.svg
```

## Things you should know before you start

1. **DuckDNS cannot point at AWS Amplify or Lambda.** Your requirements (keep `bramyya.duckdns.org`, keep all files on your server) mean one server running Docker. That is how this project is built. The FastAPI app still exports a Mangum `handler`, but API Gateway buffers responses, so token-by-token streaming would not work on Lambda anyway.
2. **Clerk: use a Development instance** (keys start with `pk_test_` / `sk_test_`). As far as I know, Clerk production instances need DNS records on a domain you control, which DuckDNS does not allow. Development instances are free and fine for personal use; Clerk shows a small "development mode" badge on the sign-in page.
3. **The 70B model name changes.** `llama-3.1-70b-versatile` and Mixtral were retired by Groq. The default is `llama-3.3-70b-versatile`; change `GROQ_MODEL` in `.env` if Groq retires it too.
4. **"<100 ms"** is realistic only for time-to-first-token, and depends on your distance to Groq's servers. The final `done` event includes `ttft_ms` (measured on the server) so you can check it.
5. **Voices:** speech uses the voices installed on the *user's* device. Android and Windows with language packs usually have Hindi and Telugu; if not, the app shows a warning. Chrome and Edge are best; Firefox has no speech recognition.
6. **Supabase free projects pause after a period of inactivity.** If chat history stops loading after a long break, open the Supabase dashboard and restore the project.

## Step-by-step: from zero to running

### Step 1: Get a server (free)
You need a Linux server with a public IP and ports 80 and 443 reachable. Use a machine you already have, or a free-tier VM (for example Oracle Cloud Always Free, or AWS EC2 if your account's free tier still covers it; check current terms so you stay at $0). Ubuntu 22.04/24.04 with at least 1 GB RAM works; add 1 to 2 GB of swap if the Next.js build runs out of memory. Note its **public IP**.

In your provider's firewall / security group, allow inbound **TCP 80, TCP 443, UDP 443**.

### Step 2: Point bramyya.duckdns.org at the server
1. Log in at https://www.duckdns.org and copy your **token**.
2. Make sure the subdomain `bramyya` exists and set its IP to your server's public IP.
3. The `duckdns` container in this project keeps that IP updated automatically.

### Step 3: Supabase (database)
1. Create a free project at https://supabase.com.
2. Open **SQL Editor → New query**, paste all of `backend/supabase_schema.sql`, click **Run**.
3. **Project Settings → API**: copy the **Project URL** and the **service_role** (or secret) key. This key goes only in the backend `.env`.

### Step 4: Clerk (sign-in)
1. Create an application at https://dashboard.clerk.com (choose Email and/or Google).
2. **API Keys**: copy the **Publishable key** (`pk_test_…`) and **Secret key** (`sk_test_…`).
3. On the same page click **Show API URLs** and copy the **Frontend API URL**. This is `CLERK_ISSUER`.

### Step 5: Groq (AI)
Create a free key at https://console.groq.com/keys (`gsk_…`).

### Step 6: Put the project on the server
```bash
# from your computer
scp -r bramyya-ai youruser@SERVER_IP:~/
# on the server
cd ~/bramyya-ai
bash deploy/server-setup.sh      # installs Docker + firewall; then log out and back in once
```

### Step 7: Fill in the secrets
```bash
cd ~/bramyya-ai
cp .env.example .env
nano .env        # paste every value from steps 2 to 5
```

### Step 8: Start everything
```bash
docker compose up -d --build
docker compose ps                # all four services should be "running"
docker compose logs -f caddy     # first start: watch it obtain the HTTPS certificate
```
The first build takes a few minutes. Check the API: `curl https://bramyya.duckdns.org/api/health` should return `{"status":"ok",...}`.

### Step 9: Test it
Open https://bramyya.duckdns.org and sign up. Then check:
- Text question: tokens appear live with Markdown formatting.
- Switch **English / हिन्दी / తెలుగు**: the background and accent colours change (indigo, saffron, emerald) and answers come in that language.
- Tap the **mic**, allow the permission, speak: your words appear, then send automatically.
- Speaker icon on: the answer is **read aloud sentence by sentence while it is still being generated**. Tap the stop button to cut it off.
- Refresh the page: the History sidebar shows your saved chats.

## Everyday operations

| Task | Command (in `~/bramyya-ai`) |
|---|---|
| See logs | `docker compose logs -f backend` |
| Update after editing code | `docker compose up -d --build` |
| Restart | `docker compose restart` |
| Stop | `docker compose down` (certificates are kept in the `caddy_data` volume) |

## Local development (optional)

```bash
# backend
cd backend && python -m venv venv && source venv/bin/activate && pip install -r requirements.txt
export CLERK_ISSUER=... SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... GROQ_API_KEY=...
export ALLOWED_ORIGINS=http://localhost:3000 CLERK_AUTHORIZED_PARTIES=http://localhost:3000
uvicorn main:app --reload --port 8000

# frontend (second terminal)
cd frontend && npm install
printf 'NEXT_PUBLIC_API_BASE=http://localhost:8000\nNEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...\nCLERK_SECRET_KEY=sk_test_...\n' > .env.local
npm run dev
```
The microphone works on `localhost` without HTTPS.

## Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| Browser says site unreachable | DuckDNS IP wrong, or ports 80/443 blocked in the cloud firewall |
| Caddy cannot get a certificate | Port 80 must be open from the internet and the domain must already resolve to this server |
| Sign-in loops or 401 on `/api/*` | `CLERK_ISSUER` must be exactly the Frontend API URL; `CLERK_AUTHORIZED_PARTIES` must be `https://bramyya.duckdns.org` |
| Answer arrives all at once | Something between you and Caddy is buffering (a CDN or proxy); the Caddyfile already disables buffering for `/api/*` |
| Mic button does nothing | Use Chrome/Edge over HTTPS and allow the microphone for the site |
| No spoken answer in Telugu/Hindi | The device has no voice for that language; install the language's text-to-speech voice in the OS or Android settings |
| "AI is busy" message | Groq free-tier rate limit; wait a moment |
| Chat history empty or errors after a long idle | Supabase free project paused; restore it in the dashboard |

## API reference

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Public health check |
| POST | `/api/chat/stream` | Body `{message, conversation_id?, language: "en"\|"hi"\|"te"}`; returns SSE events `meta`, `token`, `done`, `error` |
| GET / PUT | `/api/me/settings` | Language and speaker preference |
| GET | `/api/conversations` | List chats |
| GET | `/api/conversations/{id}/messages` | Load one chat |
| DELETE | `/api/conversations/{id}` | Delete a chat |

All routes except `/api/health` require `Authorization: Bearer <Clerk session token>`.
