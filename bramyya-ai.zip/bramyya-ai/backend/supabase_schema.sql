-- Run this once in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run.

create extension if not exists pgcrypto;

create table if not exists public.user_settings (
  user_id       text primary key,                       -- Clerk user id (user_xxx)
  language      text not null default 'en' check (language in ('en','hi','te')),
  voice_enabled boolean not null default true,
  updated_at    timestamptz not null default now()
);

create table if not exists public.conversations (
  id          uuid primary key default gen_random_uuid(),
  user_id     text not null,
  title       text not null default 'New chat',
  language    text not null default 'en',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists conversations_user_idx on public.conversations (user_id, updated_at desc);

create table if not exists public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id         text not null,
  role            text not null check (role in ('user','assistant')),
  content         text not null,
  language        text,
  created_at      timestamptz not null default now()
);
create index if not exists messages_conv_idx on public.messages (conversation_id, created_at);

-- Lock the tables down. Only the backend (service_role key, which bypasses RLS) can read/write.
-- With RLS on and no policies, the public anon key cannot touch any row.
alter table public.user_settings enable row level security;
alter table public.conversations enable row level security;
alter table public.messages      enable row level security;
