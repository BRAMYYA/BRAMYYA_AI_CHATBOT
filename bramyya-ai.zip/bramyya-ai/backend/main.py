"""
Bramyya AI - FastAPI backend

  * Clerk session-token verification (pure ASGI middleware, SSE-safe)
  * Supabase (managed Postgres) connection interface
  * POST /api/chat/stream  -> Groq (stream=True) -> Server-Sent Events
  * Mangum adapter kept at the bottom so the same app can also run on AWS Lambda
    (note: API Gateway buffers responses, so token-by-token streaming only works
     when this app runs as a normal server behind Caddy, as in docker-compose.yml)
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Literal, Optional
from uuid import UUID

import anyio
import anyio.to_thread
import jwt
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from groq import AsyncGroq, RateLimitError
from jwt import PyJWKClient
from pydantic import BaseModel, Field
from supabase import Client, create_client

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("bramyya")

# --------------------------------------------------------------------------- #
# Configuration (all from environment variables - nothing is hard-coded)
# --------------------------------------------------------------------------- #
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
HISTORY_LIMIT = int(os.getenv("HISTORY_LIMIT", "20"))          # past messages sent to the model
HISTORY_CHAR_BUDGET = int(os.getenv("HISTORY_CHAR_BUDGET", "12000"))
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "1024"))
ALLOWED_ORIGINS = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "").split(",") if o.strip()]
AUTHORIZED_PARTIES = [o.strip() for o in os.getenv("CLERK_AUTHORIZED_PARTIES", "").split(",") if o.strip()]
DEBUG = os.getenv("DEBUG", "").lower() in {"1", "true", "yes"}

PUBLIC_PATHS = {"/api/health"}

Lang = Literal["en", "hi", "te"]

SYSTEM_PROMPTS: dict[str, str] = {
    "en": (
        "You are Bramyya AI, a friendly, fast and accurate personal assistant. "
        "Always reply in clear English. Keep answers focused and well structured; "
        "use Markdown (lists, short headings, fenced code blocks) only when it helps. "
        "Do not use emojis, because your answers may be read aloud."
    ),
    "hi": (
        "आप Bramyya AI हैं, एक मित्रवत, तेज़ और सटीक व्यक्तिगत सहायक। "
        "हमेशा शुद्ध हिंदी (देवनागरी लिपि) में उत्तर दें, चाहे उपयोगकर्ता किसी भी भाषा में पूछे। "
        "तकनीकी शब्द ज़रूरत पड़ने पर अंग्रेज़ी में लिख सकते हैं। उत्तर संक्षिप्त और स्पष्ट रखें। "
        "इमोजी का प्रयोग न करें, क्योंकि उत्तर बोलकर सुनाए जा सकते हैं।"
    ),
    "te": (
        "మీరు Bramyya AI, స్నేహపూర్వకమైన, వేగవంతమైన, ఖచ్చితమైన వ్యక్తిగత సహాయకుడు. "
        "వినియోగదారు ఏ భాషలో అడిగినా ఎల్లప్పుడూ తెలుగులో (తెలుగు లిపిలో) సమాధానం ఇవ్వండి. "
        "అవసరమైతే సాంకేతిక పదాలను ఆంగ్లంలో రాయవచ్చు. సమాధానాలు స్పష్టంగా, క్లుప్తంగా ఉంచండి. "
        "సమాధానాలు గట్టిగా చదివి వినిపించవచ్చు కాబట్టి ఎమోజీలు వాడకండి."
    ),
}


def require_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


# --------------------------------------------------------------------------- #
# Clerk token verification
# --------------------------------------------------------------------------- #
class ClerkVerifier:
    """Verifies Clerk session JWTs (RS256) against the instance's JWKS endpoint."""

    def __init__(self, issuer: str, authorized_parties: list[str]) -> None:
        self.issuer = issuer.rstrip("/")
        self.authorized_parties = authorized_parties
        # PyJWKClient caches the signing keys, so only the first request hits the network.
        self.jwks = PyJWKClient(f"{self.issuer}/.well-known/jwks.json", cache_keys=True, lifespan=3600)

    def verify(self, token: str) -> dict[str, Any]:
        signing_key = self.jwks.get_signing_key_from_jwt(token)
        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=self.issuer,
            options={"verify_aud": False, "require": ["exp", "iat", "sub"]},
            leeway=15,
        )
        azp = claims.get("azp")
        if self.authorized_parties and azp and azp not in self.authorized_parties:
            raise jwt.InvalidTokenError("Token was not issued for this site")
        return claims


class ClerkAuthMiddleware:
    """
    Pure ASGI middleware (does not buffer or wrap streaming responses).
    Every /api/* route except PUBLIC_PATHS requires `Authorization: Bearer <Clerk token>`.
    The verified Clerk user id is exposed as `request.state.user_id`.
    """

    def __init__(self, app) -> None:
        self.app = app

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path: str = scope["path"]
        if scope["method"] == "OPTIONS" or not path.startswith("/api/") or path in PUBLIC_PATHS:
            await self.app(scope, receive, send)
            return

        headers = {k.decode().lower(): v.decode() for k, v in scope["headers"]}
        auth = headers.get("authorization", "")
        token = auth[7:].strip() if auth.lower().startswith("bearer ") else ""
        if not token:
            await JSONResponse({"detail": "Missing bearer token"}, status_code=401)(scope, receive, send)
            return

        verifier: ClerkVerifier = scope["app"].state.verifier
        try:
            claims = await anyio.to_thread.run_sync(verifier.verify, token)
        except Exception as exc:  # expired, bad signature, wrong issuer, JWKS unreachable ...
            log.info("Rejected token: %s", exc)
            await JSONResponse({"detail": "Invalid or expired session"}, status_code=401)(scope, receive, send)
            return

        scope.setdefault("state", {})["user_id"] = claims["sub"]
        await self.app(scope, receive, send)


# --------------------------------------------------------------------------- #
# Supabase connection interface (sync client, always called through a thread)
# --------------------------------------------------------------------------- #
class Db:
    def __init__(self, url: str, service_key: str) -> None:
        self.client: Client = create_client(url, service_key)

    # settings -------------------------------------------------------------- #
    def get_settings(self, user_id: str) -> dict[str, Any]:
        rows = self.client.table("user_settings").select("*").eq("user_id", user_id).limit(1).execute().data
        return rows[0] if rows else {"user_id": user_id, "language": "en", "voice_enabled": True}

    def upsert_settings(self, user_id: str, values: dict[str, Any]) -> dict[str, Any]:
        payload = {"user_id": user_id, **values, "updated_at": datetime.now(timezone.utc).isoformat()}
        return self.client.table("user_settings").upsert(payload, on_conflict="user_id").execute().data[0]

    # conversations --------------------------------------------------------- #
    def list_conversations(self, user_id: str, limit: int = 50) -> list[dict[str, Any]]:
        return (
            self.client.table("conversations")
            .select("id,title,language,updated_at")
            .eq("user_id", user_id)
            .order("updated_at", desc=True)
            .limit(limit)
            .execute()
            .data
        )

    def get_conversation(self, user_id: str, conversation_id: str) -> Optional[dict[str, Any]]:
        rows = (
            self.client.table("conversations")
            .select("*")
            .eq("id", conversation_id)
            .eq("user_id", user_id)
            .limit(1)
            .execute()
            .data
        )
        return rows[0] if rows else None

    def create_conversation(self, user_id: str, title: str, language: str) -> dict[str, Any]:
        return (
            self.client.table("conversations")
            .insert({"user_id": user_id, "title": title, "language": language})
            .execute()
            .data[0]
        )

    def touch_conversation(self, conversation_id: str) -> None:
        self.client.table("conversations").update(
            {"updated_at": datetime.now(timezone.utc).isoformat()}
        ).eq("id", conversation_id).execute()

    def delete_conversation(self, user_id: str, conversation_id: str) -> None:
        self.client.table("conversations").delete().eq("id", conversation_id).eq("user_id", user_id).execute()

    # messages -------------------------------------------------------------- #
    def recent_messages(self, conversation_id: str, limit: int) -> list[dict[str, Any]]:
        rows = (
            self.client.table("messages")
            .select("role,content")
            .eq("conversation_id", conversation_id)
            .order("created_at", desc=True)
            .limit(limit)
            .execute()
            .data
        )
        return list(reversed(rows))

    def list_messages(self, conversation_id: str) -> list[dict[str, Any]]:
        return (
            self.client.table("messages")
            .select("id,role,content,created_at")
            .eq("conversation_id", conversation_id)
            .order("created_at")
            .execute()
            .data
        )

    def add_message(self, conversation_id: str, user_id: str, role: str, content: str, language: str) -> None:
        self.client.table("messages").insert(
            {
                "conversation_id": conversation_id,
                "user_id": user_id,
                "role": role,
                "content": content,
                "language": language,
            }
        ).execute()


# --------------------------------------------------------------------------- #
# App lifecycle
# --------------------------------------------------------------------------- #
@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.verifier = ClerkVerifier(require_env("CLERK_ISSUER"), AUTHORIZED_PARTIES)
    app.state.db = Db(require_env("SUPABASE_URL"), require_env("SUPABASE_SERVICE_ROLE_KEY"))
    app.state.groq = AsyncGroq(api_key=require_env("GROQ_API_KEY"), max_retries=1, timeout=60.0)
    log.info("Bramyya AI backend ready (model=%s)", GROQ_MODEL)
    yield
    await app.state.groq.close()


app = FastAPI(
    title="Bramyya AI API",
    lifespan=lifespan,
    docs_url="/api/docs" if DEBUG else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if DEBUG else None,
)

# Added first = inner; CORS is added last so it wraps auth and decorates 401s too.
app.add_middleware(ClerkAuthMiddleware)
if ALLOWED_ORIGINS:  # only needed for local dev (frontend :3000 -> backend :8000)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=ALLOWED_ORIGINS,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )


# --------------------------------------------------------------------------- #
# Schemas
# --------------------------------------------------------------------------- #
class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
    conversation_id: Optional[UUID] = None
    language: Lang = "en"


class SettingsIn(BaseModel):
    language: Optional[Lang] = None
    voice_enabled: Optional[bool] = None


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def sse(event: str, data: dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def prepare_turn(db: Db, user_id: str, body: ChatRequest) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Runs in a worker thread: resolve/create the conversation, read history, store the user message."""
    if body.conversation_id:
        conv = db.get_conversation(user_id, str(body.conversation_id))
        if not conv:
            raise HTTPException(status_code=404, detail="Conversation not found")
        history = db.recent_messages(conv["id"], HISTORY_LIMIT)
    else:
        title = " ".join(body.message.split())[:60] or "New chat"
        conv = db.create_conversation(user_id, title, body.language)
        history = []
    db.add_message(conv["id"], user_id, "user", body.message, body.language)
    return conv, history


def build_messages(language: str, history: list[dict[str, Any]], user_text: str) -> list[dict[str, str]]:
    kept: list[dict[str, str]] = []
    budget = HISTORY_CHAR_BUDGET
    for m in reversed(history):  # newest first, stop when the budget is used
        budget -= len(m["content"])
        if budget < 0:
            break
        kept.append({"role": m["role"], "content": m["content"]})
    kept.reverse()
    return [{"role": "system", "content": SYSTEM_PROMPTS[language]}, *kept, {"role": "user", "content": user_text}]


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #
@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {"status": "ok", "model": GROQ_MODEL}


@app.get("/api/me/settings")
async def get_settings(request: Request):
    return await asyncio.to_thread(request.app.state.db.get_settings, request.state.user_id)


@app.put("/api/me/settings")
async def put_settings(body: SettingsIn, request: Request):
    values = body.model_dump(exclude_none=True)
    if not values:
        return await asyncio.to_thread(request.app.state.db.get_settings, request.state.user_id)
    return await asyncio.to_thread(request.app.state.db.upsert_settings, request.state.user_id, values)


@app.get("/api/conversations")
async def list_conversations(request: Request):
    return await asyncio.to_thread(request.app.state.db.list_conversations, request.state.user_id)


@app.get("/api/conversations/{conversation_id}/messages")
async def conversation_messages(conversation_id: UUID, request: Request):
    db: Db = request.app.state.db
    conv = await asyncio.to_thread(db.get_conversation, request.state.user_id, str(conversation_id))
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return await asyncio.to_thread(db.list_messages, str(conversation_id))


@app.delete("/api/conversations/{conversation_id}")
async def delete_conversation(conversation_id: UUID, request: Request):
    await asyncio.to_thread(request.app.state.db.delete_conversation, request.state.user_id, str(conversation_id))
    return {"ok": True}


@app.post("/api/chat/stream")
async def chat_stream(body: ChatRequest, request: Request) -> StreamingResponse:
    user_id: str = request.state.user_id
    db: Db = request.app.state.db
    groq: AsyncGroq = request.app.state.groq

    # Everything that can fail with a normal HTTP error happens before streaming starts.
    conv, history = await asyncio.to_thread(prepare_turn, db, user_id, body)
    messages = build_messages(body.language, history, body.message)

    async def event_stream() -> AsyncIterator[str]:
        parts: list[str] = []
        saved = False
        started = time.perf_counter()
        first_token_ms: Optional[int] = None

        yield sse("meta", {"conversation_id": conv["id"], "model": GROQ_MODEL})
        try:
            stream = await groq.chat.completions.create(
                model=GROQ_MODEL,
                messages=messages,
                stream=True,
                temperature=0.6,
                max_tokens=MAX_TOKENS,
            )
            async for chunk in stream:
                if not chunk.choices:
                    continue
                token = chunk.choices[0].delta.content
                if not token:
                    continue
                if first_token_ms is None:
                    first_token_ms = int((time.perf_counter() - started) * 1000)
                parts.append(token)
                yield sse("token", {"t": token})

            answer = "".join(parts)
            if answer:
                await asyncio.to_thread(db.add_message, conv["id"], user_id, "assistant", answer, body.language)
                await asyncio.to_thread(db.touch_conversation, conv["id"])
                saved = True
            yield sse("done", {"conversation_id": conv["id"], "ttft_ms": first_token_ms})
        except RateLimitError:
            yield sse("error", {"code": "rate_limit", "message": "The AI is busy right now. Please try again in a moment."})
        except Exception:  # noqa: BLE001 - report any upstream failure to the client
            log.exception("Streaming failed")
            yield sse("error", {"code": "upstream", "message": "Something went wrong while generating the answer."})
        finally:
            # Client closed the tab / pressed stop: keep what was generated so far.
            answer = "".join(parts)
            if answer and not saved:
                with anyio.CancelScope(shield=True):
                    await asyncio.to_thread(db.add_message, conv["id"], user_id, "assistant", answer, body.language)
                    await asyncio.to_thread(db.touch_conversation, conv["id"])

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # tell any proxy not to buffer
        },
    )


# --------------------------------------------------------------------------- #
# AWS Lambda entry point (optional). Handler: main.handler
# --------------------------------------------------------------------------- #
try:
    from mangum import Mangum

    handler = Mangum(app, lifespan="auto")
except ImportError:  # mangum is only needed on Lambda
    handler = None
